"""
from environments.environment import OthelloEnv

def play_game(agent_1, agent_2, board_size=5):
    env = OthelloEnv(board_size=board_size)
    obs = env.reset()
    done = False

    while not done:
        if env.current_player == 1:
            action = agent_1.select_action(obs)
        else:
            action = agent_2.select_action(obs)

        obs, reward, done, info = env.step(action)

    return info["winner"], info["disc_diff"]


def evaluate_fair(agent_a_class, agent_b_class, board_size=5, n_games=200):
    a_wins = 0
    b_wins = 0
    draws = 0

    for _ in range(n_games // 2):
        agent_a = agent_a_class(board_size)
        agent_b = agent_b_class(board_size)

        winner, _ = play_game(agent_a, agent_b, board_size)

        if winner == 1:
            a_wins += 1
        elif winner == -1:
            b_wins += 1
        else:
            draws += 1

    for _ in range(n_games // 2):
        agent_b = agent_b_class(board_size)
        agent_a = agent_a_class(board_size)

        winner, _ = play_game(agent_b, agent_a, board_size)

        if winner == 1:
            b_wins += 1
        elif winner == -1:
            a_wins += 1
        else:
            draws += 1

    return {
        "agent_a_wins": a_wins,
        "agent_b_wins": b_wins,
        "draws": draws,
        "n_games": n_games,
    }
"""

from environments.environment import OthelloEnv


def play_game(agent_1, agent_2, board_size=5):
    """
    Odehraje jednu celou partii.

    agent_1 vždy hraje za hráče 1.
    agent_2 vždy hraje za hráče -1.
    """
    env = OthelloEnv(board_size=board_size)
    observation = env.reset()
    done = False

    while not done:
        if env.current_player == 1:
            action = agent_1.select_action(observation)
        else:
            action = agent_2.select_action(observation)

        observation, _, done, info = env.step(action)

    return info["winner"]


def evaluate_fair(
    agent_a,
    agent_b_class,
    board_size=5,
    n_games=200,
):
    """
    Vyhodnotí již existující instanci agent_a proti agent_b_class.

    Polovinu her hraje agent_a jako hráč 1.
    Druhou polovinu hraje agent_a jako hráč -1.
    """
    if n_games <= 0:
        raise ValueError("n_games must be positive.")

    a_wins = 0
    a_losses = 0
    draws = 0

    games_as_first = n_games // 2
    games_as_second = n_games - games_as_first

    # Agent A hraje jako hráč 1.
    for _ in range(games_as_first):
        agent_b = agent_b_class(board_size)

        winner = play_game(
            agent_1=agent_a,
            agent_2=agent_b,
            board_size=board_size,
        )

        if winner == 1:
            a_wins += 1
        elif winner == -1:
            a_losses += 1
        else:
            draws += 1

    # Agent A hraje jako hráč -1.
    for _ in range(games_as_second):
        agent_b = agent_b_class(board_size)

        winner = play_game(
            agent_1=agent_b,
            agent_2=agent_a,
            board_size=board_size,
        )

        if winner == -1:
            a_wins += 1
        elif winner == 1:
            a_losses += 1
        else:
            draws += 1

    win_rate = a_wins / n_games

    # Skóre, kde výhra = 1, remíza = 0.5, prohra = 0.
    score = (a_wins + 0.5 * draws) / n_games

    return {
        "wins": a_wins,
        "draws": draws,
        "losses": a_losses,
        "n_games": n_games,
        "win_rate": win_rate,
        "score": score,
    }